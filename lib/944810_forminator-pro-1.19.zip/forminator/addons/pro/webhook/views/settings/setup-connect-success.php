<div class="forminator-integration-popup__header">

	<h3 id="forminator-integration-popup__title" class="sui-box-title sui-lg" style="overflow: initial; white-space: normal; text-overflow: initial;">
		<?php
		/* translators: Integration name */
		echo esc_html( sprintf( __( '%1$s Added', 'forminator' ), 'Webhook' ) );
		?>
	</h3>

</div>

<p id="forminator-integration-popup__description" class="sui-description" style="text-align: center;">
	<?php esc_html_e( 'You can now go to your forms and assign them to this integration', 'forminator' ); ?>
</p>