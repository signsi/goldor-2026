<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       rocket.ch
 * @since      1.0.0
 *
 * @package    Rocketpager_Options
 * @subpackage Rocketpager_Options/admin/partials
 */
?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->
