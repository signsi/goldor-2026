<?php

/**
 * The admin-specific functionality of the plugin.
 *
 * @link       rocket.ch
 * @since      1.0.0
 *
 * @package    Rocketpager_Options
 * @subpackage Rocketpager_Options/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Rocketpager_Options
 * @subpackage Rocketpager_Options/admin
 * @author     Rocket GmbH <info@rocket.ch>
 */
class Rocketpager_Options_Admin
{

    /**
     * The ID of this plugin.
     *
     * @since    1.0.0
     * @access   private
     * @var      string    $plugin_name    The ID of this plugin.
     */
    private $plugin_name;

    /**
     * The version of this plugin.
     *
     * @since    1.0.0
     * @access   private
     * @var      string    $version    The current version of this plugin.
     */
    private $version;

    /**
     * Initialize the class and set its properties.
     *
     * @since    1.0.0
     * @param      string    $plugin_name       The name of this plugin.
     * @param      string    $version    The version of this plugin.
     */
    public function __construct($plugin_name, $version)
    {

        $this->plugin_name = $plugin_name;
        $this->version = $version;
    }

    /**
     * Register the stylesheets for the admin area.
     *
     * @since    1.0.0
     */
    public function enqueue_styles()
    {

        /**
         * This function is provided for demonstration purposes only.
         *
         * An instance of this class should be passed to the run() function
         * defined in Rocketpager_Options_Loader as all of the hooks are defined
         * in that particular class.
         *
         * The Rocketpager_Options_Loader will then create the relationship
         * between the defined hooks and the functions defined in this
         * class.
         */

        wp_enqueue_style($this->plugin_name, plugin_dir_url(__FILE__) . 'css/rocketpager-options-admin.css', array(), $this->version, 'all');
    }

    /**
     * Register the JavaScript for the admin area.
     *
     * @since    1.0.0
     */
    public function enqueue_scripts()
    {

        /**
         * This function is provided for demonstration purposes only.
         *
         * An instance of this class should be passed to the run() function
         * defined in Rocketpager_Options_Loader as all of the hooks are defined
         * in that particular class.
         *
         * The Rocketpager_Options_Loader will then create the relationship
         * between the defined hooks and the functions defined in this
         * class.
         */

        wp_enqueue_script($this->plugin_name, plugin_dir_url(__FILE__) . 'js/rocketpager-options-admin.js', array('jquery'), $this->version, false);
    }


    public function kirki_init()
    {

        if (class_exists('Kirki')) {
            Kirki::add_config('theme_config_id', array(
                'capability' => 'edit_theme_options',
                'option_type' => 'theme_mod',
            ));

            Kirki::add_panel('rocketpager', array(
                'priority'    => 10,
                'title'       => esc_html__('RocketPager', 'rocketpager'),
                'description' => esc_html__('RocketPager options', 'rocketpager'),
            ));

            function do_not_filter_anything( $value ) { return $value; }




            /**
             *  GENERAL
             */

            Kirki::add_section('general', array(
                'title'          => esc_html__('General', 'rocketpager'),
                'description'    => esc_html__('Geben Sie einige allgemeine Informationen an.', 'rocketpager'),
                'panel'          => 'rocketpager',
                'priority'       => 10,
            ));

            Kirki::add_field('company_name', [
                'type'     => 'text',
                'settings' => 'company_name',
                'label'    => esc_html__('Name der Firma', 'rocketpager'),
                'section'  => 'general',
                'default'  => esc_html__('Rocket GmbH', 'rocketpager'),
                'priority' => 10,
            ]);

            Kirki::add_field('company_slogan', [
                'type'     => 'text',
                'settings' => 'company_slogan',
                'label'    => esc_html__('Slogan der Firma', 'rocketpager'),
                'section'  => 'general',
                'default'  => esc_html__('Powerful advertising', 'rocketpager'),
                'priority' => 10,
            ]);

            Kirki::add_field('company_street', [
                'type'     => 'text',
                'settings' => 'company_street',
                'label'    => esc_html__('Strasse der Firma', 'rocketpager'),
                'section'  => 'general',
                'default'  => esc_html__('Neuweg 10', 'rocketpager'),
                'priority' => 10,
            ]);

            Kirki::add_field('company_plz_city', [
                'type'     => 'text',
                'settings' => 'company_plz_city',
                'label'    => esc_html__('Firma PLZ und Ort', 'rocketpager'),
                'section'  => 'general',
                'default'  => esc_html__('CH-6003 Luzern', 'rocketpager'),
                'priority' => 10,
            ]);

            Kirki::add_field('company_phone', [
                'type'     => 'text',
                'settings' => 'company_phone',
                'label'    => esc_html__('Telefon der Firma', 'rocketpager'),
                'section'  => 'general',
                'default'  => esc_html__('+4141 500 10 10', 'rocketpager'),
                'priority' => 10,
            ]);

            Kirki::add_field('company_email', [
                'type'     => 'text',
                'settings' => 'company_email',
                'label'    => esc_html__('E-Mail der Firma', 'rocketpager'),
                'section'  => 'general',
                'default'  => esc_html__('info@rocket.ch', 'rocketpager'),
                'priority' => 10,
            ]);

            Kirki::add_field('company_page', [
                'type'     => 'text',
                'settings' => 'company_page',
                'label'    => esc_html__('Seite der Firma', 'rocketpager'),
                'section'  => 'general',
                'default'  => esc_html__('www.rocket.ch', 'rocketpager'),
                'priority' => 10,
            ]);

            Kirki::add_field('maintenance_mode', [
                'type'        => 'checkbox',
                'settings'    => 'maintenance_mode',
                'label'       => esc_html__('Wartungsmodus aktivieren', 'rocketpager'),
                'section'     => 'general',
                'default'     => false,
                'priority' => 10,
            ]);

                        /**
             *  Social Media Profil
             */

            Kirki::add_section('social media profil', array(
                'title'          => esc_html__('Social Media Profil', 'rocketpager'),
                'description'    => esc_html__('Stellen Sie Social-Media-Links bereit', 'rocketpager'),
                'panel'          => 'rocketpager',
                'section'     => 'general',
                'priority'       => 11,
            ));

            Kirki::add_field('linkedin', [
                'type'     => 'text',
                'settings' => 'linkedin',
                'label'    => esc_html__('Linkedin', 'rocketpager'),
                'section'  => 'social media profil',
                'default'  => '',
                'priority' => 11,
            ]); 
            Kirki::add_field('facebook', [
                'type'     => 'text',
                'settings' => 'facebook',
                'label'    => esc_html__('Facebook', 'rocketpager'),
                'section'  => 'social media profil',
                'default'  => '',
                'priority' => 11,
            ]); 
            Kirki::add_field('instagram', [
                'type'     => 'text',
                'settings' => 'instagram',
                'label'    => esc_html__('Instagram', 'rocketpager'),
                'section'  => 'social media profil',
                'default'  => '',
                'priority' => 11,
            ]); 
            Kirki::add_field('twitter', [
                'type'     => 'text',
                'settings' => 'twitter',
                'label'    => esc_html__('Twitter', 'rocketpager'),
                'section'  => 'social media profil',
                'default'  => '',
                'priority' => 11,
            ]); 
            Kirki::add_field('xing', [
                'type'     => 'text',
                'settings' => 'xing',
                'label'    => esc_html__('XING', 'rocketpager'),
                'section'  => 'social media profil',
                'default'  => '',
                'priority' => 11,
            ]); 
            Kirki::add_field('youtube', [
                'type'     => 'text',
                'settings' => 'youtube',
                'label'    => esc_html__('Youtube', 'rocketpager'),
                'section'  => 'social media profil',
                'default'  => '',
                'priority' => 11,
            ]); 
            Kirki::add_field('google_plus', [
                'type'     => 'text',
                'settings' => 'google_plus',
                'label'    => esc_html__('Google Plus', 'rocketpager'),
                'section'  => 'social media profil',
                'default'  => '',
                'priority' => 11,
            ]); 


            /**
             *  Header
             */

            Kirki::add_section('header', array(
                'title'          => esc_html__('Header', 'rocketpager'),
                'description'    => esc_html__('Header Optionen.', 'rocketpager'),
                'panel'          => 'rocketpager',
                'priority'       => 160,
            ));

            Kirki::add_field( 'header_megamenue', [  
                'type'        => 'checkbox',
                'settings'    => 'header_megamenue',
                'label'       => esc_html__( 'Megamenü aktivieren', 'rocketpager' ),
                'section'     => 'header',
                'default'     => true,
            ] );

  
            /**
             *  Footer
             */

            Kirki::add_section('footer', array(
                'title'          => esc_html__('Footer', 'rocketpager'),
                'description'    => esc_html__('Footer Optionen.', 'rocketpager'),
                'panel'          => 'rocketpager',
                'priority'       => 160,
            ));
            
            /**
             * Ausrichtung Disclaimer
             */

            Kirki::add_field('disclaimer_ausrichtung',[
                'type'           => 'radio-buttonset',
                'title'          => esc_html__('Disclaimer Ausrichtung ', 'rocketpager'),
                'label'          => esc_html__('Disclaimer Ausrichtung ', 'rocketpager'),
                'description'    => esc_html__('Wählen Sie eine Position für einen Disclaimer', 'rocketpager'),
                'settings'       => 'disclaimer_ausrichtung',
                'section'        => 'footer',
                'priority'       => 180,
                'default'     => 'text-center',
                'choices'     => [
                    'text-left' => esc_html__( 'linksbündig', 'rocketpager' ), 
                    'text-center' => esc_html__( 'zentriert', 'rocketpager' ),
                    'text-right' => esc_html__( 'rechtsbündig', 'rocketpager' ),
                    
                    
                ],
            ]);


            /**
             *  LOGOS
             */

            $default_logo = get_template_directory_uri() . '/dist/images/logo-rocket.svg';
            $default_logo_black = get_template_directory_uri() . '/dist/images/logo-rocket-black.svg';


            Kirki::add_section('logos', array(
                'title'          => esc_html__('Logos', 'rocketpager'),
                'description'    => esc_html__('Wählen Sie die einzelnen Logos auf der gesamten Website aus.', 'rocketpager'),
                'panel'          => 'rocketpager',
                'priority'       => 160,
            ));
            Kirki::add_field('logo_main', [
                'type'        => 'image',
                'settings'    => 'logo_main',
                'label'       => esc_html__('Logo (Main)', 'kirki'),
                'description' => esc_html__('Das Hauptlogo.', 'kirki'),
                'section'     => 'logos',
                'default'     => $default_logo,
            ]);

            Kirki::add_field('logo_footer', [
                'type'        => 'image',
                'settings'    => 'logo_footer',
                'label'       => esc_html__('Logo (Footer)', 'kirki'),
                'description' => esc_html__('Logo Footer.', 'kirki'),
                'section'     => 'logos',
                'default'     =>  $default_logo,
            ]);

            Kirki::add_field('logo_negative', [
                'type'        => 'image',
                'settings'    => 'logo_negative',
                'label'       => esc_html__('Logo (Negative)', 'kirki'),
                'description' => esc_html__('Negatives Logo.', 'kirki'),
                'section'     => 'logos',
                'default'     => $default_logo_black,
            ]);

            Kirki::add_field('logo_sticky', [
                'type'        => 'image',
                'settings'    => 'logo_sticky',
                'label'       => esc_html__('Logo (Sticky)', 'kirki'),
                'description' => esc_html__('Sticky Logo.', 'kirki'),
                'section'     => 'logos',
                'default'     => $default_logo_black,
            ]);

                        
            /**
             *  Sonstiges
             */

            Kirki::add_section('sonstiges', array(
                'title'          => esc_html__('Sonstiges', 'rocketpager'),
                'description'    => esc_html__('Andere Optionen', 'rocketpager'),
                'panel'          => 'rocketpager',
                'priority'       => 160,
            ));

            
            Kirki::add_field('code_vor_head', [
                'type'     => 'code',
                'settings' => 'code_vor_head',
                'label'    => html_entity_decode('Code vor dem schliessenden &lt;/head&gt;-Tag',ENT_COMPAT, 'UTF-8'),
                'section'  => 'sonstiges',
                'default'  => esc_html__('', 'rocketpager'),
                'priority' => 10,
                'choices'     => [
                    'language' => 'css',
                    'language' => 'JS',
                ],
            ]);

            Kirki::add_field('code_vor_body', [
                'type'     => 'code',
                'settings' => 'code_vor_body',
                'label'    => html_entity_decode('Code unmittelbar nach dem öffnenden &#x3C;body&#x3E;-Tag',ENT_COMPAT, 'UTF-8'),
                'section'  => 'sonstiges',
                'default'  => esc_html__('', 'rocketpager'),
                'priority' => 10,
                'choices'     => [
                    'language' => 'css',
                    'language' => 'JS',
                ],
            ]);
            
            Kirki::add_field('google_api_key', [
                'type'     => 'text',
                'settings' => 'google_api_key',
                'label'    => esc_html__('Google API Key', 'rocketpager'),
                'section'  => 'sonstiges',
                'default'  => esc_html__('', 'rocketpager'),
                'priority' => 10,
            ]);

            Kirki::add_field('nootiz_id', [
                'type'     => 'text',
                'settings' => 'nootiz_id',
                'label'    => esc_html__('Nootiz ID', 'rocketpager'),
                'section'  => 'sonstiges',
                'default'  => esc_html__('', 'rocketpager'),
                'priority' => 10,
            ]);

                        
            /**
             *  Fixed CTA
             */

            Kirki::add_section('fixed_cta', array(
                'title'          => esc_html__('Fixed CTA', 'rocketpager'),
                'description'    => esc_html__('Wählen Sie Ihr individuelles CTA', 'rocketpager'),
                'panel'          => 'rocketpager',
                'priority'       => 160,
            ));

            Kirki::add_field('fixed_cta', [
                'type'     => 'toggle',
                'settings' => 'fixed_cta',
                'label'    => esc_html__('CTA aktivieren', 'rocketpager'),
                'section'  => 'fixed_cta',
                'default'  => '1',
                'priority' => 10,
            ]);
            Kirki::add_field('language_switcher', [
                'type'     => 'checkbox',
                'settings' => 'language_switcher',
                'label'    => esc_html__('Sprach-Switcher', 'rocketpager'),
                'section'  => 'fixed_cta',
                'default'  => true,
                'priority' => 10,
            ]);
            Kirki::add_field('search', [
                'type'     => 'checkbox',
                'settings' => 'search',
                'label'    => esc_html__('Suche', 'rocketpager'),
                'section'  => 'fixed_cta',
                'default'  => true,
                'priority' => 10,
            ]);
            Kirki::add_field('social_share', [
                'type'     => 'checkbox',
                'settings' => 'social_share',
                'label'    => esc_html__('Social Share', 'rocketpager'),
                'section'  => 'fixed_cta',
                'default'  => true,
                'priority' => 10,
            ]);
            Kirki::add_field('link', [
                'type'     => 'checkbox',
                'settings' => 'link',
                'label'    => esc_html__('Link', 'rocketpager'),
                'section'  => 'fixed_cta',
                'default'  => true,
                'priority' => 10,
            ]);
            Kirki::add_field('link_text', [
                'type'     => 'text',
                'settings' => 'link_text',
                'label'    => esc_html__('Link Text', 'rocketpager'),
                'section'  => 'fixed_cta',
                'default'  => 'rocket.ch',
                'priority' => 10,
            ]);
            Kirki::add_field('link_url', [
                'type'     => 'text',
                'settings' => 'link_url',
                'label'    => esc_html__('Link URL', 'rocketpager'),
                'section'  => 'fixed_cta',
                'default'    => 'https://www.rocket.ch',
                'priority' => 10,
            ]);
        }
    }
}