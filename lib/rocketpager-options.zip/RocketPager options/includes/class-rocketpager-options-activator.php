<?php

/**
 * Fired during plugin activation
 *
 * @link       rocket.ch
 * @since      1.0.0
 *
 * @package    Rocketpager_Options
 * @subpackage Rocketpager_Options/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Rocketpager_Options
 * @subpackage Rocketpager_Options/includes
 * @author     Rocket GmbH <info@rocket.ch>
 */
class Rocketpager_Options_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

	}

}
