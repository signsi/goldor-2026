<?php
declare( strict_types = 1 );

namespace WP_Defender\Component;

class Crypt extends \Calotes\Base\Component {

	/**
	 * Generates cryptographically secure pseudo-random bytes.
	 *
	 * @param int $bytes
	 *
	 * @return string
	*/
	public static function random_bytes( int $bytes ): string {
		// Try with random_bytes.
		if ( function_exists( 'random_bytes' ) ) {
			try {
				$rand = random_bytes( $bytes );
				if ( is_string( $rand ) && strlen( $rand ) === $bytes ) {
					return $rand;
				}
			} catch ( \Exception $e ) {
				$_this = new self();
				$_this->log( $e->getMessage(), 'internal.log' );
			}
		}
		// Try with openssl_random_pseudo_bytes.
		if ( function_exists( 'openssl_random_pseudo_bytes' ) ) {
			$rand = openssl_random_pseudo_bytes( $bytes, $strong );
			if ( is_string( $rand ) && strlen( $rand ) === $bytes ) {
				return $rand;
			}
		}
		// Not safe. Use in extreme cases.
		$return = '';
		for ( $i = 0; $i < $bytes; $i++ ) {
			$return .= chr( mt_rand( 0, 255 ) );
		}

		return $return;
	}

	/**
	 * Generates cryptographically secure pseudo-random integers.
	 *
	 * @param int $min
	 * @param int $max
	 *
	 * @return int
	 */
	public static function random_int( $min = 0, $max = 0x7FFFFFFF ): int {
		if ( function_exists( 'random_int' ) ) {
			try {
				return random_int( $min, $max );
			} catch ( \Exception $e ) {
				$_this = new self();
				$_this->log( $e->getMessage(), 'internal.log' );
			}
		}
		$diff = $max - $min;
		$bytes = self::random_bytes( 4 );
		if ( 4 !== strlen( $bytes ) ) {
			throw new \RuntimeException( 'Unable to get 4 bytes' );
		}
		$val = unpack( 'nint', $bytes );
		$val = $val['int'] & 0x7FFFFFFF;
		// Convert to [0,1].
		$fp = (float) $val / 2147483647.0;

		return (int) ( round( $fp * $diff ) + $min );
	}

	/**
	 * Compare two strings to avoid timing attacks.
	 *
	 * @param string $expected
	 * @param string $actual
	 *
	 * @return bool
	 */
	public static function compare_lines( $expected, $actual ): bool {
		if ( function_exists( 'hash_equals' ) ) {
			return hash_equals( $expected, $actual );
		}

		$len_expected = mb_strlen( $expected, '8bit' );
		$len_actual = mb_strlen( $actual, '8bit' );
		$len = min( $len_expected, $len_actual );

		$result = 0;
		for ( $i = 0; $i < $len; $i++ ) {
			$result |= ord( $expected[ $i ] ) ^ ord( $actual[ $i ] );
		}
		$result |= $len_expected ^ $len_actual;

		return 0 === $result;
	}

	/**
	 * @param string $plaintext
	 * @param string $key
	 *
	 * @return string
	 */
	private static function encrypt_data( $plaintext, $key ) {
		$cipher = 'aes-256-cbc';
		$iv_len = openssl_cipher_iv_length( $cipher );
		$iv = self::random_bytes( $iv_len );
		$ciphertext_raw = openssl_encrypt( $plaintext, 'aes-256-cbc', $key, OPENSSL_RAW_DATA, $iv );
		$hmac = hash_hmac( 'sha256', $ciphertext_raw, $key, true );

		return base64_encode( $iv . $hmac . $ciphertext_raw );
	}

	/**
	 * @param string $encrypt_data
	 * @param string $key
	 *
	 * @return string
	 */
	private static function decrypt_data( $encrypt_data, $key ) {
		$str = base64_decode( $encrypt_data );
		$cipher = 'aes-256-cbc';
		$iv_len = openssl_cipher_iv_length( $cipher );
		$iv = substr( $str, 0, $iv_len );
		$ciphertext_raw = substr( $str, $iv_len + 32 );

		return openssl_decrypt( $ciphertext_raw, $cipher, $key, OPENSSL_RAW_DATA, $iv );
	}

	/**
	 * @param string $data
	 *
	 * @return string
	 */
	public static function get_decrypted_string( $data ): string {
		$key = file_get_contents(  __DIR__ . '/def.key' );

		return false !== $key ? self::decrypt_data( $data, $key ) : '';
	}

	/**
	 * @param string $data
	 *
	 * @return string
	 */
	public static function get_encrypted_string( $data ): string {
		$key = file_get_contents(  __DIR__ . '/def.key' );

		return false !== $key ? self::encrypt_data( $data, $key ) : '';
	}
}